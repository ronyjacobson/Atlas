This is the only file needed for parsing and making the DB except from Yago. 
Enjoy! :)